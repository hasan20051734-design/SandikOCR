// Intentionally unused placeholder; MediaProjection access is handled in CaptureService.
