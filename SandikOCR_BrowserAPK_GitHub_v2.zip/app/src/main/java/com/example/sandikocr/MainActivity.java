package com.example.sandikocr;

import android.app.Activity;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 1001;
    private TextView status, timeText;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        status = findViewById(R.id.status);
        timeText = findViewById(R.id.timeText);

        findViewById(R.id.start).setOnClickListener(v -> requestCapture());
        findViewById(R.id.stop).setOnClickListener(v ->
                stopService(new Intent(this, CaptureService.class)));
        findViewById(R.id.browser).setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("http://127.0.0.1:8765/"));
            startActivity(i);
        });
    }

    private void requestCapture() {
        MediaProjectionManager mpm =
                (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_CAPTURE && resultCode == RESULT_OK && data != null) {
            Intent s = new Intent(this, CaptureService.class);
            s.putExtra("resultCode", resultCode);
            s.putExtra("data", data);
            startForegroundService(s);
            status.setText("OCR çalışıyor. Yerel tarayıcı: http://127.0.0.1:8765/");
        } else if (requestCode == REQ_CAPTURE) {
            status.setText("Ekran izni verilmedi.");
        }
    }
}
