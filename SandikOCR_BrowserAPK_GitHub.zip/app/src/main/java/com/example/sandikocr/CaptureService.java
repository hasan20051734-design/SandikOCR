package com.example.sandikocr;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import androidx.annotation.Nullable;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.*;
import java.net.*;
import java.nio.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.*;

public class CaptureService extends Service {
    private static final String CHANNEL = "sandik_ocr";
    private static final int NOTIF = 42;
    private MediaProjection projection;
    private ImageReader reader;
    private HandlerThread thread;
    private Handler handler;
    private TextRecognizer recognizer;
    private LocalServer server;
    private final AtomicInteger seconds = new AtomicInteger(-1);
    private long lastOcr = 0;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(NOTIF, notification("Sandık OCR çalışıyor"));
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        server = new LocalServer(8765, seconds);
        server.start();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        int resultCode = intent.getIntExtra("resultCode", Activity.RESULT_CANCELED);
        Intent data = intent.getParcelableExtra("data");
        if (data != null && projection == null) startProjection(resultCode, data);
        return START_STICKY;
    }

    private void startProjection(int resultCode, Intent data) {
        MediaProjectionManager m =
                (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = m.getMediaProjection(resultCode, data);

        DisplayMetrics dm = getResources().getDisplayMetrics();
        int w = Math.min(dm.widthPixels, 1280);
        int h = Math.min(dm.heightPixels, 720);
        int density = dm.densityDpi;

        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2);
        thread = new HandlerThread("capture");
        thread.start();
        handler = new Handler(thread.getLooper());

        projection.createVirtualDisplay(
                "SandikOCR", w, h, density,
                android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.getSurface(), null, handler);

        reader.setOnImageAvailableListener(r -> processLatest(r), handler);
    }

    private void processLatest(ImageReader r) {
        Image image = null;
        try {
            image = r.acquireLatestImage();
            if (image == null) return;
            long now = System.currentTimeMillis();
            if (now - lastOcr < 900) return;
            lastOcr = now;

            Image.Plane p = image.getPlanes()[0];
            int width = image.getWidth();
            int height = image.getHeight();
            int pixelStride = p.getPixelStride();
            int rowStride = p.getRowStride();
            int rowPadding = rowStride - pixelStride * width;

            Bitmap padded = Bitmap.createBitmap(
                    width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888);
            ByteBuffer buf = p.getBuffer();
            buf.rewind();
            padded.copyPixelsFromBuffer(buf);

            Bitmap bitmap = Bitmap.createBitmap(padded, 0, 0, width, height);
            padded.recycle();

            InputImage input = InputImage.fromBitmap(bitmap, 0);
            recognizer.process(input)
                .addOnSuccessListener(handler::post, result -> parseText(result))
                .addOnFailureListener(e -> {})
                .addOnCompleteListener(t -> bitmap.recycle());
        } catch (Exception ignored) {
            if (image != null) image.close();
        } finally {
            if (image != null) image.close();
        }
    }

    private void parseText(Text result) {
        String text = result.getText();
        Pattern p = Pattern.compile("\b([0-5]?\d)\s*[:.]\s*([0-5]\d)\b");
        Matcher m = p.matcher(text);
        int best = -1;
        while (m.find()) {
            int sec = Integer.parseInt(m.group(1)) * 60 + Integer.parseInt(m.group(2));
            if (sec >= 0 && sec <= 599) best = Math.max(best, sec);
        }
        if (best >= 0) seconds.set(best);
    }

    @Override public void onDestroy() {
        if (reader != null) reader.close();
        if (projection != null) projection.stop();
        if (thread != null) thread.quitSafely();
        if (recognizer != null) recognizer.close();
        if (server != null) server.stopServer();
        super.onDestroy();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "Sandık OCR",
                    NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    private Notification notification(String text) {
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("Sandık OCR")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build();
    }

    @Override public android.os.IBinder onBind(Intent intent) { return null; }

    static class MediaProjectionManagerCompat {
        private final Context c;
        MediaProjectionManagerCompat(Context c) { this.c = c; }
        MediaProjection get(int result, Intent data) {
            android.media.projection.MediaProjectionManager m =
                    (android.media.projection.MediaProjectionManager)
                    c.getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            return m.getMediaProjection(result, data);
        }
    }

    static class LocalServer {
        private final int port;
        private final AtomicInteger value;
        private volatile boolean running;
        private ServerSocket socket;

        LocalServer(int port, AtomicInteger value) { this.port = port; this.value = value; }

        void start() {
            new Thread(() -> {
                try {
                    socket = new ServerSocket(port, 20, InetAddress.getByName("127.0.0.1"));
                    running = true;
                    while (running) {
                        Socket s = socket.accept();
                        handle(s);
                    }
                } catch (Exception ignored) {}
            }, "local-http").start();
        }

        void handle(Socket s) {
            try {
                BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
                String line = in.readLine();
                while (line != null && !line.isEmpty()) line = in.readLine();

                String body;
                if (line == null) body = "";
                String request = "";
                // The first request line is read above; for this tiny server, always serve the page.
                body = PAGE.replace("%%SECONDS%%", String.valueOf(value.get()));
                byte[] bytes = body.getBytes("UTF-8");

                OutputStream out = s.getOutputStream();
                String headers = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n" +
                        "Cache-Control: no-store\r\nContent-Length: " + bytes.length + "\r\nConnection: close\r\n\r\n";
                out.write(headers.getBytes("UTF-8"));
                out.write(bytes);
                out.flush();
                s.close();
            } catch (Exception ignored) {}
        }

        void stopServer() {
            running = false;
            try { if (socket != null) socket.close(); } catch (Exception ignored) {}
        }

        private static final String PAGE = "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>" +
                "<title>Sandık Geri Sayım</title><style>body{font-family:sans-serif;text-align:center;padding:25px}#t{font-size:80px;font-weight:bold}</style></head>" +
                "<body><h2>Sandık OCR</h2><div id='t'>--:--</div><p id='s'>OCR bekleniyor…</p>" +
                "<script>let last=-1,at=0;function draw(){let v=last;if(v<0){document.getElementById('t').textContent='--:--';return}let x=Math.max(0,v-Math.floor((Date.now()-at)/1000));let m=Math.floor(x/60),s=x%60;document.getElementById('t').textContent=String(m).padStart(2,'0')+':'+String(s).padStart(2,'0');}async function poll(){try{let r=await fetch(location.href+'?t='+Date.now(),{cache:'no-store'});let txt=await r.text();let z=txt.match(/data-seconds="(-?\d+)"/);if(z){let n=parseInt(z[1]);if(n>=0){last=n;at=Date.now();document.getElementById('s').textContent='OCR güncellendi';}}}catch(e){}draw();}setInterval(poll,1000);setInterval(draw,200);poll();</script>" +
                "<div data-seconds='%%SECONDS%%'></div></body></html>";
    }
}
